import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: (import.meta as any).env.VITE_GEMINI_API_KEY || "" });

export interface JobTranslations {
  ku: {
    title: string;
    description: string;
    requirements: string;
    location: string;
  };
  ar: {
    title: string;
    description: string;
    requirements: string;
    location: string;
  };
  en: {
    title: string;
    description: string;
    requirements: string;
    location: string;
  };
}

export async function translateJob(jobData: {
  title: string;
  description: string;
  requirements: string;
  location: string;
}, sourceLang: string = 'en'): Promise<JobTranslations> {
  const model = "gemini-3-flash-preview";
  
  const prompt = `Translate the following job details into Kurdish (Sorani) and Arabic. 
  Also provide the English version (even if it's the source).
  Return the result as a JSON object matching this structure:
  {
    "ku": { "title": "...", "description": "...", "requirements": "...", "location": "..." },
    "ar": { "title": "...", "description": "...", "requirements": "...", "location": "..." },
    "en": { "title": "...", "description": "...", "requirements": "...", "location": "..." }
  }

  Job Details:
  Title: ${jobData.title}
  Description: ${jobData.description}
  Requirements: ${jobData.requirements}
  Location: ${jobData.location}
  
  Important: For Kurdish, use Sorani dialect.`;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: [{ parts: [{ text: prompt }] }],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            ku: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                description: { type: Type.STRING },
                requirements: { type: Type.STRING },
                location: { type: Type.STRING },
              },
              required: ["title", "description", "requirements", "location"],
            },
            ar: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                description: { type: Type.STRING },
                requirements: { type: Type.STRING },
                location: { type: Type.STRING },
              },
              required: ["title", "description", "requirements", "location"],
            },
            en: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                description: { type: Type.STRING },
                requirements: { type: Type.STRING },
                location: { type: Type.STRING },
              },
              required: ["title", "description", "requirements", "location"],
            },
          },
          required: ["ku", "ar", "en"],
        },
      },
    });

    const text = response.text;
    if (!text) throw new Error("No response from Gemini");
    return JSON.parse(text);
  } catch (error) {
    console.error("Translation failed:", error);
    // Fallback to original data if translation fails
    return {
      en: jobData,
      ku: jobData,
      ar: jobData
    };
  }
}
