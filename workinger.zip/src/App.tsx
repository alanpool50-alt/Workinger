import React, { useState, useEffect } from 'react';
import { 
  Search, 
  MapPin, 
  Filter, 
  Bookmark, 
  MessageSquare, 
  PlusSquare, 
  User, 
  ChevronRight, 
  Bell, 
  Settings, 
  LogOut,
  Briefcase,
  CheckCircle2,
  Clock,
  ArrowLeft,
  Send,
  Paperclip,
  FileText,
  Globe,
  Database as DatabaseIcon,
  BarChart3,
  Trash2,
  LayoutDashboard
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { translateJob } from "./services/geminiTranslation";
import { translations, Language } from './translations';
import { Job, User as UserType, Application } from './types';

export default function App() {
  const [lang, setLang] = useState<Language>('en');
  const [activeTab, setActiveTab] = useState('explore');
  const [jobs, setJobs] = useState<Job[]>([]);
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [isApplyModalOpen, setIsApplyModalOpen] = useState(false);
  const [savedJobs, setSavedJobs] = useState<Job[]>([]);
  const [appliedJobs, setAppliedJobs] = useState<Application[]>([]);
  const [messages, setMessages] = useState<any[]>([]);
  const [isRTL, setIsRTL] = useState(false);
  const [user, setUser] = useState<UserType | null>(null);
  const [isLoginOpen, setIsLoginOpen] = useState(true);
  const [isAdminMode, setIsAdminMode] = useState(false);

  useEffect(() => {
    setIsRTL(lang === 'ar' || lang === 'ku');
    fetchJobs();
    if (user) {
      fetchUserData();
    }
  }, [lang, user]);

  // SEO and Dynamic Meta Tags
  useEffect(() => {
    let title = t('seoTitle');
    let description = t('seoDescription');

    // Update HTML lang attribute
    document.documentElement.lang = lang;

    if (selectedJob) {
      title = `${selectedJob.title} ${t('jobAt')} ${selectedJob.company_name} | Workinger`;
      description = `${selectedJob.title} at ${selectedJob.company_name} in ${selectedJob.location}. ${selectedJob.description.substring(0, 150)}...`;
      
      // Inject JSON-LD for JobPosting
      const ldJson = {
        "@context": "https://schema.org/",
        "@type": "JobPosting",
        "title": selectedJob.title,
        "description": selectedJob.description,
        "datePosted": selectedJob.posted_at,
        "hiringOrganization": {
          "@type": "Organization",
          "name": selectedJob.company_name,
          "logo": selectedJob.company_logo
        },
        "jobLocation": {
          "@type": "Place",
          "address": {
            "@type": "PostalAddress",
            "addressLocality": selectedJob.location
          }
        },
        "baseSalary": {
          "@type": "MonetaryAmount",
          "currency": "USD",
          "value": {
            "@type": "QuantitativeValue",
            "value": selectedJob.salary,
            "unitText": "YEAR"
          }
        }
      };

      let script = document.getElementById('job-ld-json') as HTMLScriptElement | null;
      if (!script) {
        script = document.createElement('script');
        script.id = 'job-ld-json';
        script.type = 'application/ld+json';
        document.head.appendChild(script);
      }
      script.textContent = JSON.stringify(ldJson);
    } else {
      const script = document.getElementById('job-ld-json');
      if (script) script.remove();
    }

    document.title = title;
    const metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc) metaDesc.setAttribute('content', description);
    
    const ogTitle = document.querySelector('meta[property="og:title"]');
    if (ogTitle) ogTitle.setAttribute('content', title);
    
    const ogDesc = document.querySelector('meta[property="og:description"]');
    if (ogDesc) ogDesc.setAttribute('content', description);

    // Update Canonical Link
    let canonical = document.querySelector('link[rel="canonical"]');
    if (!canonical) {
      canonical = document.createElement('link');
      canonical.setAttribute('rel', 'canonical');
      document.head.appendChild(canonical);
    }
    const url = selectedJob 
      ? `https://workinger.app/jobs/${selectedJob.id}?lang=${lang}` 
      : `https://workinger.app/?lang=${lang}`;
    canonical.setAttribute('href', url);

  }, [selectedJob, lang]);

  const fetchJobs = async () => {
    try {
      const res = await fetch('/api/jobs');
      const data = await res.json();
      setJobs(data);
    } catch (e) {
      console.error("Failed to fetch jobs", e);
    }
  };

  const fetchUserData = async () => {
    if (!user) return;
    try {
      const savedRes = await fetch(`/api/users/${user.id}/saved`);
      const savedData = await savedRes.json();
      setSavedJobs(savedData);

      const appsRes = await fetch(`/api/users/${user.id}/applications`);
      const appsData = await appsRes.json();
      setAppliedJobs(appsData);

      const msgRes = await fetch(`/api/messages/${user.id}`);
      const msgData = await msgRes.json();
      setMessages(msgData);
    } catch (e) {
      console.error("Failed to fetch user data", e);
    }
  };

  const t = (key: string) => translations[key]?.[lang] || key;

  const handleApply = async (message: string) => {
    if (!selectedJob || !user) return;
    try {
      await fetch('/api/applications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: user.id,
          job_id: selectedJob.id,
          message
        })
      });
      setIsApplyModalOpen(false);
      fetchUserData();
      alert(t('applicationSent'));
    } catch (e) {
      console.error("Failed to apply", e);
    }
  };

  const toggleSaveJob = async (job: Job) => {
    if (!user) return;
    const isSaved = savedJobs.some(sj => sj.id === job.id);
    try {
      if (isSaved) {
        await fetch(`/api/saved_jobs/${user.id}/${job.id}`, { method: 'DELETE' });
      } else {
        await fetch('/api/saved_jobs', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ user_id: user.id, job_id: job.id })
        });
      }
      fetchUserData();
    } catch (e) {
      console.error("Failed to toggle save", e);
    }
  };

  const handlePostJob = async (jobData: any) => {
    try {
      // Show a loading state or message if possible
      console.log("Translating job details...");
      const jobTranslations = await translateJob({
        title: jobData.title,
        description: jobData.description,
        requirements: jobData.requirements,
        location: jobData.location
      });

      const finalJobData = {
        ...jobData,
        translations: JSON.stringify(jobTranslations)
      };

      await fetch('/api/jobs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(finalJobData)
      });
      fetchJobs();
      setActiveTab('explore');
      alert("Job posted and translated successfully!");
    } catch (e) {
      console.error("Failed to post job", e);
      alert("Failed to post job. Please try again.");
    }
  };

  const [loginError, setLoginError] = useState<string | null>(null);

  const handleLogin = async (credentials: any) => {
    setLoginError(null);
    console.log("Attempting login with:", credentials.email);
    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(credentials)
      });
      if (res.ok) {
        const userData = await res.json();
        console.log("Login successful:", userData.email);
        setUser(userData);
        setIsLoginOpen(false);
        if (userData.role === 'admin') {
          setIsAdminMode(true);
        }
      } else {
        const errorData = await res.json();
        setLoginError(errorData.error || "Invalid credentials");
      }
    } catch (e) {
      console.error("Login failed", e);
      setLoginError("Connection error. Please try again.");
    }
  };

  const renderContent = () => {
    if (isAdminMode) return <AdminDashboard t={t} isRTL={isRTL} />;

    switch (activeTab) {
      case 'explore': return <ExploreView jobs={jobs} onSelectJob={setSelectedJob} onSaveJob={toggleSaveJob} savedJobs={savedJobs} t={t} isRTL={isRTL} lang={lang} />;
      case 'saved': return <SavedView savedJobs={savedJobs} appliedJobs={appliedJobs} onSelectJob={setSelectedJob} onSaveJob={toggleSaveJob} t={t} isRTL={isRTL} lang={lang} />;
      case 'post': return <PostJobView onPost={handlePostJob} t={t} isRTL={isRTL} />;
      case 'messages': return <MessagesView messages={messages} t={t} isRTL={isRTL} />;
      case 'profile': return <ProfileView user={user!} t={t} isRTL={isRTL} setLang={setLang} lang={lang} setIsAdminMode={setIsAdminMode} isAdmin={user?.role === 'admin'} logout={() => { setUser(null); setIsLoginOpen(true); setIsAdminMode(false); }} />;
      default: return <ExploreView jobs={jobs} onSelectJob={setSelectedJob} onSaveJob={toggleSaveJob} savedJobs={savedJobs} t={t} isRTL={isRTL} lang={lang} />;
    }
  };

  if (isLoginOpen) {
    return <LoginView onLogin={handleLogin} t={t} isRTL={isRTL} error={loginError} />;
  }

  return (
    <div className={`min-h-screen bg-[#F5F5F5] font-sans text-[#1A1A1A] ${isRTL ? 'rtl' : 'ltr'}`} dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Top Header */}
      <header className="sticky top-0 z-40 bg-white border-b border-black/5 px-4 py-3 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-2">
          {isAdminMode && (
            <button onClick={() => setIsAdminMode(false)} className="p-2 hover:bg-gray-100 rounded-full text-emerald-600">
              <ArrowLeft size={20} className={isRTL ? 'rotate-180' : ''} />
            </button>
          )}
          <h1 className="text-xl font-bold tracking-tight text-emerald-600">
            {isAdminMode ? t('adminDashboard') : 'Workinger'}
          </h1>
        </div>
        <div className="flex items-center gap-3">
          <button className="p-2 hover:bg-black/5 rounded-full transition-colors">
            <Bell size={20} />
          </button>
          <button className="p-2 hover:bg-black/5 rounded-full transition-colors" onClick={() => setActiveTab('profile')}>
            <Settings size={20} />
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="pb-24 max-w-4xl mx-auto px-4 pt-4">
        <AnimatePresence mode="wait">
          <motion.div
            key={isAdminMode ? 'admin' : activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            {renderContent()}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Bottom Navigation */}
      {!isAdminMode && (
        <nav className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-black/5 px-2 py-2 flex justify-around items-center shadow-[0_-4px_10px_rgba(0,0,0,0.05)]">
          <NavButton active={activeTab === 'explore'} icon={<Search size={22} />} label={t('explore')} onClick={() => setActiveTab('explore')} />
          <NavButton active={activeTab === 'saved'} icon={<Bookmark size={22} />} label={t('saved')} onClick={() => setActiveTab('saved')} />
          <NavButton active={activeTab === 'post'} icon={<PlusSquare size={22} />} label={t('postJob')} onClick={() => setActiveTab('post')} />
          <NavButton active={activeTab === 'messages'} icon={<MessageSquare size={22} />} label={t('messages')} onClick={() => setActiveTab('messages')} />
          <NavButton active={activeTab === 'profile'} icon={<User size={22} />} label={t('profile')} onClick={() => setActiveTab('profile')} />
        </nav>
      )}

      {/* Job Details Overlay */}
      <AnimatePresence>
        {selectedJob && (
          <JobDetailsOverlay 
            job={selectedJob} 
            onClose={() => setSelectedJob(null)} 
            onApply={() => setIsApplyModalOpen(true)}
            onSave={() => toggleSaveJob(selectedJob)}
            onMessage={() => {
              setSelectedJob(null);
              setActiveTab('messages');
            }}
            isSaved={savedJobs.some(sj => sj.id === selectedJob.id)}
            t={t}
            isRTL={isRTL}
            lang={lang}
          />
        )}
      </AnimatePresence>

      {/* Apply Modal */}
      <AnimatePresence>
        {isApplyModalOpen && (
          <ApplyModal 
            onClose={() => setIsApplyModalOpen(false)} 
            onConfirm={handleApply}
            t={t}
            isRTL={isRTL}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

function LoginView({ onLogin, t, isRTL, error }: { onLogin: (creds: any) => void, t: (k: string) => string, isRTL: boolean, error: string | null }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  return (
    <div className="min-h-screen bg-emerald-600 flex items-center justify-center p-6">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-white w-full max-w-md rounded-[32px] p-8 shadow-2xl space-y-8"
      >
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-black text-emerald-600">Workinger</h1>
          <p className="text-gray-500 font-medium">{t('findJobs')}</p>
        </div>

        {error && (
          <div className="bg-red-50 text-red-600 p-4 rounded-2xl text-sm font-bold text-center border border-red-100">
            {error}
          </div>
        )}

        <div className="space-y-4">
          <Input label="Email" placeholder="alan.aa@me.com" value={email} onChange={(e: any) => { console.log("Email changed:", e.target.value); setEmail(e.target.value); }} />
          <Input label="Password" placeholder="••••••••" type="password" value={password} onChange={(e: any) => { console.log("Password changed:", e.target.value); setPassword(e.target.value); }} />
          <button 
            onClick={() => onLogin({ email, password })}
            className="w-full py-4 bg-emerald-600 text-white font-black rounded-2xl shadow-lg shadow-emerald-600/20 active:scale-95 transition-all"
          >
            {t('login')}
          </button>
        </div>

        <div className="text-center text-xs text-gray-400">
          <p>Admin: alan.aa@me.com / Pkjuhnkp0897</p>
          <p>User: alanpool50@yahoo.com / password123</p>
        </div>
      </motion.div>
    </div>
  );
}

function AdminDashboard({ t, isRTL }: { t: (k: string) => string, isRTL: boolean }) {
  const [activeView, setActiveView] = useState<'analytics' | 'database'>('analytics');
  const [tables, setTables] = useState<string[]>([]);
  const [selectedTable, setSelectedTable] = useState<string | null>(null);
  const [tableData, setTableData] = useState<{ data: any[], columns: any[] } | null>(null);
  const [analytics, setAnalytics] = useState<any>(null);

  useEffect(() => {
    fetchTables();
    fetchAnalytics();
  }, []);

  useEffect(() => {
    if (selectedTable) {
      fetchTableData(selectedTable);
    }
  }, [selectedTable]);

  const fetchTables = async () => {
    const res = await fetch('/api/admin/tables');
    const data = await res.json();
    setTables(data);
    if (data.length > 0) setSelectedTable(data[0]);
  };

  const fetchTableData = async (name: string) => {
    const res = await fetch(`/api/admin/tables/${name}`);
    const data = await res.json();
    setTableData(data);
  };

  const fetchAnalytics = async () => {
    const res = await fetch('/api/admin/analytics');
    const data = await res.json();
    setAnalytics(data);
  };

  const handleDelete = async (id: number) => {
    if (!selectedTable) return;
    if (confirm("Are you sure you want to delete this record?")) {
      await fetch(`/api/admin/tables/${selectedTable}/${id}`, { method: 'DELETE' });
      fetchTableData(selectedTable);
      fetchAnalytics();
    }
  };

  return (
    <div className="space-y-6">
      {/* Admin Nav */}
      <div className="flex gap-2 p-1 bg-gray-100 rounded-2xl">
        <button 
          onClick={() => setActiveView('analytics')}
          className={`flex-1 py-3 rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition-all ${activeView === 'analytics' ? 'bg-white text-emerald-600 shadow-sm' : 'text-gray-500'}`}
        >
          <BarChart3 size={18} /> {t('analytics')}
        </button>
        <button 
          onClick={() => setActiveView('database')}
          className={`flex-1 py-3 rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition-all ${activeView === 'database' ? 'bg-white text-emerald-600 shadow-sm' : 'text-gray-500'}`}
        >
          <DatabaseIcon size={18} /> {t('database')}
        </button>
      </div>

      {activeView === 'analytics' ? (
        <div className="space-y-6">
          {/* Stats Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <StatCard label={t('totalUsers')} value={analytics?.totalUsers || 0} icon={<User size={20} />} color="bg-blue-500" />
            <StatCard label={t('totalJobs')} value={analytics?.totalJobs || 0} icon={<Briefcase size={20} />} color="bg-emerald-500" />
            <StatCard label={t('totalApplications')} value={analytics?.totalApplications || 0} icon={<CheckCircle2 size={20} />} color="bg-purple-500" />
            <StatCard label="Companies" value={analytics?.totalCompanies || 0} icon={<Briefcase size={20} />} color="bg-orange-500" />
          </div>

          {/* Recent Activity */}
          <div className="bg-white p-6 rounded-3xl shadow-sm border border-black/5">
            <h3 className="text-lg font-black mb-4">Recent Applications</h3>
            <div className="space-y-4">
              {analytics?.recentApplications.map((app: any) => (
                <div key={app.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-2xl">
                  <div>
                    <p className="font-bold">{app.user_name}</p>
                    <p className="text-xs text-gray-500">applied for {app.job_title}</p>
                  </div>
                  <span className="text-[10px] text-gray-400">{new Date(app.applied_at).toLocaleDateString()}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Table Selector */}
          <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
            {tables.map(table => (
              <button 
                key={table}
                onClick={() => setSelectedTable(table)}
                className={`px-6 py-2 rounded-full text-sm font-bold whitespace-nowrap transition-all ${selectedTable === table ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/20' : 'bg-white border border-black/5 text-gray-500 hover:bg-gray-50'}`}
              >
                {table}
              </button>
            ))}
          </div>

          {/* Table View */}
          <div className="bg-white rounded-3xl shadow-sm border border-black/5 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="bg-gray-50 text-gray-400 uppercase text-[10px] font-black tracking-wider">
                  <tr>
                    {tableData?.columns.map((col: any) => (
                      <th key={col.name} className="px-6 py-4">{col.name}</th>
                    ))}
                    <th className="px-6 py-4">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-black/5">
                  {tableData?.data.map((row: any) => (
                    <tr key={row.id} className="hover:bg-gray-50 transition-colors">
                      {tableData.columns.map((col: any) => (
                        <td key={col.name} className="px-6 py-4 font-medium text-gray-600 max-w-[200px] truncate">
                          {String(row[col.name])}
                        </td>
                      ))}
                      <td className="px-6 py-4">
                        <button onClick={() => handleDelete(row.id)} className="p-2 text-red-400 hover:bg-red-50 rounded-lg transition-colors">
                          <Trash2 size={16} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function StatCard({ label, value, icon, color }: { label: string, value: number, icon: React.ReactNode, color: string }) {
  return (
    <div className="bg-white p-4 rounded-3xl shadow-sm border border-black/5 space-y-3">
      <div className={`w-10 h-10 ${color} text-white rounded-2xl flex items-center justify-center shadow-lg`}>
        {icon}
      </div>
      <div>
        <p className="text-[10px] font-black text-gray-400 uppercase tracking-wider">{label}</p>
        <p className="text-2xl font-black">{value}</p>
      </div>
    </div>
  );
}

function NavButton({ active, icon, label, onClick }: { active: boolean, icon: React.ReactNode, label: string, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={`flex flex-col items-center gap-1 px-3 py-1 rounded-xl transition-all ${active ? 'text-emerald-600' : 'text-gray-400 hover:text-gray-600'}`}
    >
      {icon}
      <span className="text-[10px] font-medium uppercase tracking-wider">{label}</span>
    </button>
  );
}

function ExploreView({ jobs, onSelectJob, onSaveJob, savedJobs, t, isRTL, lang }: { jobs: Job[], onSelectJob: (job: Job) => void, onSaveJob: (job: Job) => void, savedJobs: Job[], t: (k: string) => string, isRTL: boolean, lang: string }) {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredJobs = jobs.filter(job => {
    const translations = job.translations ? JSON.parse(job.translations) : null;
    const currentTranslation = translations ? translations[lang] : null;
    
    const title = currentTranslation?.title || job.title;
    const company = job.company_name;
    const location = currentTranslation?.location || job.location;

    return title.toLowerCase().includes(searchQuery.toLowerCase()) ||
           company.toLowerCase().includes(searchQuery.toLowerCase()) ||
           location.toLowerCase().includes(searchQuery.toLowerCase());
  });

  return (
    <div className="space-y-4">
      {/* Search Section */}
      <div className="bg-white p-4 rounded-2xl shadow-sm border border-black/5 space-y-3">
        <div className="relative">
          <Search className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 -translate-y-1/2 text-gray-400`} size={18} />
          <input 
            type="text" 
            placeholder={t('searchJobs')} 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={`w-full bg-gray-50 border border-black/5 rounded-xl py-2.5 ${isRTL ? 'pr-10 pl-4' : 'pl-10 pr-4'} focus:outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all`}
          />
        </div>
        <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
          <FilterChip label={t('remote')} />
          <FilterChip label={t('fullTime')} />
          <FilterChip label={t('partTime')} />
          <FilterChip label="Entry Level" />
        </div>
      </div>

      {/* Job Feed */}
      <div className="space-y-3">
        {filteredJobs.map(job => (
          <JobCard 
            key={job.id} 
            job={job} 
            onClick={() => onSelectJob(job)} 
            onSave={() => onSaveJob(job)}
            isSaved={savedJobs.some(sj => sj.id === job.id)}
            t={t} 
            isRTL={isRTL} 
            lang={lang}
          />
        ))}
      </div>
    </div>
  );
}

function FilterChip({ label }: { label: string }) {
  return (
    <button className="px-4 py-1.5 bg-white border border-black/5 rounded-full text-sm font-medium hover:bg-emerald-50 hover:border-emerald-200 transition-all whitespace-nowrap">
      {label}
    </button>
  );
}

function JobCard({ job, onClick, onSave, isSaved, t, isRTL, lang }: { job: Job, onClick: () => void, onSave: () => void, isSaved: boolean, t: (k: string) => string, isRTL: boolean, lang: string, key?: React.Key }) {
  const displayJob = React.useMemo(() => {
    if (!job.translations) return job;
    try {
      const translations = JSON.parse(job.translations);
      const translated = translations[lang];
      if (translated) {
        return { ...job, ...translated };
      }
    } catch (e) {}
    return job;
  }, [job, lang]);

  return (
    <motion.div 
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className="bg-white p-4 rounded-2xl shadow-sm border border-black/5 hover:border-emerald-200 transition-all cursor-pointer group"
    >
      <div className="flex justify-between items-start mb-2">
        <div className="flex gap-3">
          <div className="w-12 h-12 bg-gray-100 rounded-xl flex items-center justify-center text-gray-400">
            {job.company_logo ? <img src={job.company_logo} alt={job.company_name} className="w-full h-full object-cover rounded-xl" /> : <Briefcase size={24} />}
          </div>
          <div>
            <h3 className="font-bold text-lg group-hover:text-emerald-600 transition-colors">{displayJob.title}</h3>
            <p className="text-gray-500 text-sm">{job.company_name}</p>
          </div>
        </div>
        <button 
          className={`p-2 transition-colors ${isSaved ? 'text-emerald-600' : 'text-gray-400 hover:text-emerald-600'}`} 
          onClick={(e) => { e.stopPropagation(); onSave(); }}
        >
          <Bookmark size={20} fill={isSaved ? "currentColor" : "none"} />
        </button>
      </div>
      
      <div className="flex flex-wrap gap-2 mb-3">
        <span className="px-2 py-1 bg-gray-100 rounded-lg text-[11px] font-bold text-gray-600 flex items-center gap-1">
          <MapPin size={12} /> {displayJob.location}
        </span>
        <span className="px-2 py-1 bg-emerald-50 rounded-lg text-[11px] font-bold text-emerald-600">
          {job.salary}
        </span>
        <span className="px-2 py-1 bg-blue-50 rounded-lg text-[11px] font-bold text-blue-600">
          {job.type}
        </span>
      </div>

      <div className="flex justify-between items-center pt-2 border-t border-black/5">
        <span className="text-[10px] text-gray-400 flex items-center gap-1">
          <Clock size={10} /> {new Date(job.posted_at).toLocaleDateString()}
        </span>
        <span className="text-emerald-600 text-xs font-bold flex items-center gap-1">
          {t('openJob')} <ChevronRight size={14} className={isRTL ? 'rotate-180' : ''} />
        </span>
      </div>
    </motion.div>
  );
}

function JobDetailsOverlay({ job, onClose, onApply, onSave, onMessage, isSaved, t, isRTL, lang }: { job: Job, onClose: () => void, onApply: () => void, onSave: () => void, onMessage: () => void, isSaved: boolean, t: (k: string) => string, isRTL: boolean, lang: string }) {
  const displayJob = React.useMemo(() => {
    if (!job.translations) return job;
    try {
      const translations = JSON.parse(job.translations);
      const translated = translations[lang];
      if (translated) {
        return { ...job, ...translated };
      }
    } catch (e) {}
    return job;
  }, [job, lang]);

  return (
    <motion.div 
      initial={{ x: '100%' }}
      animate={{ x: 0 }}
      exit={{ x: '100%' }}
      transition={{ type: 'spring', damping: 25, stiffness: 200 }}
      className="fixed inset-0 z-50 bg-white overflow-y-auto"
    >
      <div className="sticky top-0 bg-white/80 backdrop-blur-md border-b border-black/5 px-4 py-4 flex items-center gap-4">
        <button onClick={onClose} className="p-2 hover:bg-black/5 rounded-full">
          <ArrowLeft size={24} className={isRTL ? 'rotate-180' : ''} />
        </button>
        <h2 className="font-bold text-lg truncate">{displayJob.title}</h2>
      </div>

      <div className="p-6 space-y-8 pb-32">
        {/* Header Section */}
        <div className="text-center space-y-4">
          <div className="w-20 h-20 bg-gray-100 rounded-3xl mx-auto flex items-center justify-center text-gray-400 shadow-inner">
            {job.company_logo ? <img src={job.company_logo} alt={job.company_name} className="w-full h-full object-cover rounded-3xl" /> : <Briefcase size={32} />}
          </div>
          <div>
            <h1 className="text-2xl font-black">{displayJob.title}</h1>
            <p className="text-emerald-600 font-bold text-lg">{job.company_name}</p>
          </div>
          <div className="flex justify-center gap-4 text-sm text-gray-500 font-medium">
            <span className="flex items-center gap-1"><MapPin size={16} /> {displayJob.location}</span>
            <span className="flex items-center gap-1"><Clock size={16} /> {job.type}</span>
          </div>
          <div className="text-2xl font-bold text-gray-900">{job.salary}</div>
        </div>

        {/* Overview Grid */}
        <div className="grid grid-cols-2 gap-4">
          <div className="p-4 bg-gray-50 rounded-2xl border border-black/5">
            <p className="text-[10px] uppercase tracking-wider text-gray-400 font-bold mb-1">Employment Type</p>
            <p className="font-bold">{job.type}</p>
          </div>
          <div className="p-4 bg-gray-50 rounded-2xl border border-black/5">
            <p className="text-[10px] uppercase tracking-wider text-gray-400 font-bold mb-1">Experience Level</p>
            <p className="font-bold">Mid-Senior</p>
          </div>
        </div>

        {/* Description */}
        <div className="space-y-4">
          <h3 className="text-xl font-black">{t('jobDescription')}</h3>
          <p className="text-gray-600 leading-relaxed whitespace-pre-wrap">{displayJob.description}</p>
        </div>

        {/* Requirements */}
        <div className="space-y-4">
          <h3 className="text-xl font-black">{t('requirements')}</h3>
          <p className="text-gray-600 leading-relaxed whitespace-pre-wrap">{displayJob.requirements || "• 3+ years of experience\n• Strong communication skills\n• Problem-solving mindset"}</p>
        </div>

        {/* Company Section */}
        <div className="p-6 bg-emerald-50 rounded-3xl border border-emerald-100 space-y-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-emerald-600 shadow-sm">
              <Briefcase size={24} />
            </div>
            <div>
              <h4 className="font-bold text-emerald-900">{job.company_name}</h4>
              <p className="text-xs text-emerald-600 font-medium">Technology • 50-200 employees</p>
            </div>
          </div>
          <p className="text-sm text-emerald-800/80 leading-relaxed">
            {job.company_description || "Leading the way in innovative technology solutions for global markets."}
          </p>
        </div>
      </div>

      {/* Fixed Action Bar */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white/80 backdrop-blur-md border-t border-black/5 flex gap-3">
        <button className="flex-1 bg-emerald-600 text-white font-black py-4 rounded-2xl shadow-lg shadow-emerald-600/20 active:scale-95 transition-all" onClick={onApply}>
          {t('apply')}
        </button>
        <button 
          className={`p-4 rounded-2xl active:scale-95 transition-all ${isSaved ? 'bg-emerald-50 text-emerald-600' : 'bg-gray-100 text-gray-600'}`}
          onClick={onSave}
        >
          <Bookmark size={24} fill={isSaved ? "currentColor" : "none"} />
        </button>
        <button 
          onClick={onMessage}
          className="p-4 bg-gray-100 text-gray-600 rounded-2xl active:scale-95 transition-all"
        >
          <MessageSquare size={24} />
        </button>
      </div>
    </motion.div>
  );
}

function ApplyModal({ onClose, onConfirm, t, isRTL }: { onClose: () => void, onConfirm: (msg: string) => void, t: (k: string) => string, isRTL: boolean }) {
  const [step, setStep] = useState(1);
  const [message, setMessage] = useState('');
  const [fileName, setFileName] = useState('resume_alan_pool.pdf');
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setIsUploading(true);
      // Simulate upload
      setTimeout(() => {
        setFileName(file.name);
        setIsUploading(false);
      }, 1000);
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center bg-black/40 backdrop-blur-sm p-4">
      <motion.div 
        initial={{ y: '100%' }}
        animate={{ y: 0 }}
        exit={{ y: '100%' }}
        className="bg-white w-full max-w-md rounded-t-[32px] sm:rounded-[32px] p-6 shadow-2xl"
      >
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-black">{t('apply')}</h3>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full text-gray-400">
            <LogOut size={20} className="rotate-90" />
          </button>
        </div>

        {step === 1 ? (
          <div className="space-y-6">
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              onChange={handleFileChange}
              accept=".pdf,.doc,.docx"
            />
            <div 
              onClick={() => fileInputRef.current?.click()}
              className="p-6 border-2 border-dashed border-emerald-200 rounded-3xl bg-emerald-50 flex flex-col items-center gap-3 text-center cursor-pointer hover:bg-emerald-100 transition-colors"
            >
              <FileText size={40} className={isUploading ? "text-emerald-400 animate-pulse" : "text-emerald-600"} />
              <div>
                <p className="font-bold text-emerald-900">{isUploading ? "Uploading..." : fileName}</p>
                <p className="text-xs text-emerald-600">{isUploading ? "Please wait" : "Click to upload a new resume"}</p>
              </div>
            </div>
            <button 
              disabled={isUploading}
              className="w-full py-4 bg-emerald-600 text-white font-black rounded-2xl shadow-lg shadow-emerald-600/20 disabled:opacity-50" 
              onClick={() => setStep(2)}
            >
              {t('writeMessage')}
            </button>
          </div>
        ) : (
          <div className="space-y-6">
            <textarea 
              placeholder={t('writeMessage')}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full h-32 bg-gray-50 border border-black/5 rounded-2xl p-4 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
            />
            <div className="flex gap-3">
              <button className="flex-1 py-4 bg-gray-100 text-gray-600 font-bold rounded-2xl" onClick={() => setStep(1)}>
                Back
              </button>
              <button className="flex-[2] py-4 bg-emerald-600 text-white font-black rounded-2xl shadow-lg shadow-emerald-600/20" onClick={() => onConfirm(message)}>
                {t('sendApplication')}
              </button>
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
}

function SavedView({ savedJobs, appliedJobs, onSelectJob, onSaveJob, t, isRTL, lang }: { savedJobs: Job[], appliedJobs: Application[], onSelectJob: (job: Job) => void, onSaveJob: (job: Job) => void, t: (k: string) => string, isRTL: boolean, lang: string }) {
  const [subTab, setSubTab] = useState('saved');

  return (
    <div className="space-y-4">
      <div className="flex gap-2 p-1 bg-gray-100 rounded-2xl">
        <button 
          onClick={() => setSubTab('saved')}
          className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${subTab === 'saved' ? 'bg-white text-emerald-600 shadow-sm' : 'text-gray-500'}`}
        >
          {t('savedJobs')}
        </button>
        <button 
          onClick={() => setSubTab('applied')}
          className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${subTab === 'applied' ? 'bg-white text-emerald-600 shadow-sm' : 'text-gray-500'}`}
        >
          {t('appliedJobs')}
        </button>
        <button 
          onClick={() => setSubTab('recent')}
          className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${subTab === 'recent' ? 'bg-white text-emerald-600 shadow-sm' : 'text-gray-500'}`}
        >
          {t('recentlyViewed')}
        </button>
      </div>

      <div className="space-y-3">
        {subTab === 'saved' && savedJobs.map(job => (
          <JobCard 
            key={job.id} 
            job={job} 
            onClick={() => onSelectJob(job)} 
            onSave={() => onSaveJob(job)}
            isSaved={true}
            t={t} 
            isRTL={isRTL} 
            lang={lang}
          />
        ))}
        {subTab === 'applied' && appliedJobs.map(app => (
          <div key={app.id} className="bg-white p-4 rounded-2xl shadow-sm border border-black/5 flex justify-between items-center">
            <div>
              <h4 className="font-bold">{app.job_title}</h4>
              <p className="text-xs text-gray-500">{app.company_name}</p>
            </div>
            <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
              app.status === 'sent' ? 'bg-blue-50 text-blue-600' :
              app.status === 'viewed' ? 'bg-emerald-50 text-emerald-600' :
              'bg-gray-100 text-gray-600'
            }`}>
              {app.status}
            </span>
          </div>
        ))}
        {subTab === 'recent' && <p className="text-center py-12 text-gray-400 font-medium">No recently viewed jobs</p>}
      </div>
    </div>
  );
}

function PostJobView({ onPost, t, isRTL }: { onPost: (data: any) => void, t: (k: string) => string, isRTL: boolean }) {
  const [formData, setFormData] = useState({
    title: '',
    company_name: '',
    location: '',
    type: 'Full Time',
    salary: '',
    description: '',
    requirements: ''
  });

  const handleSubmit = () => {
    if (!formData.title || !formData.company_name) return alert("Please fill in title and company");
    onPost(formData);
  };

  return (
    <div className="bg-white p-6 rounded-3xl shadow-sm border border-black/5 space-y-6">
      <div className="text-center space-y-2">
        <div className="w-16 h-16 bg-emerald-50 rounded-2xl mx-auto flex items-center justify-center text-emerald-600">
          <PlusSquare size={32} />
        </div>
        <h2 className="text-2xl font-black">{t('postJob')}</h2>
        <p className="text-gray-500 text-sm">Find the best talent for your team</p>
      </div>

      <div className="space-y-4">
        <Input label={t('jobTitle')} placeholder="e.g. Senior React Developer" value={formData.title} onChange={(e: any) => setFormData({...formData, title: e.target.value})} />
        <Input label="Company Name" placeholder="e.g. TechCorp" value={formData.company_name} onChange={(e: any) => setFormData({...formData, company_name: e.target.value})} />
        <Input label={t('location')} placeholder="e.g. London or Remote" value={formData.location} onChange={(e: any) => setFormData({...formData, location: e.target.value})} />
        <div className="grid grid-cols-2 gap-4">
          <Input label="Job Type" placeholder="Full Time" value={formData.type} onChange={(e: any) => setFormData({...formData, type: e.target.value})} />
          <Input label="Salary Range" placeholder="£50k - £70k" value={formData.salary} onChange={(e: any) => setFormData({...formData, salary: e.target.value})} />
        </div>
        <div className="space-y-1.5">
          <label className="text-xs font-bold text-gray-400 uppercase tracking-wider ml-1">{t('jobDescription')}</label>
          <textarea 
            className="w-full bg-gray-50 border border-black/5 rounded-2xl p-4 h-32 focus:outline-none focus:ring-2 focus:ring-emerald-500/20" 
            value={formData.description}
            onChange={(e) => setFormData({...formData, description: e.target.value})}
          />
        </div>
        <div className="space-y-1.5">
          <label className="text-xs font-bold text-gray-400 uppercase tracking-wider ml-1">{t('requirements')}</label>
          <textarea 
            className="w-full bg-gray-50 border border-black/5 rounded-2xl p-4 h-24 focus:outline-none focus:ring-2 focus:ring-emerald-500/20" 
            value={formData.requirements}
            onChange={(e) => setFormData({...formData, requirements: e.target.value})}
          />
        </div>
        <button 
          onClick={handleSubmit}
          className="w-full py-4 bg-emerald-600 text-white font-black rounded-2xl shadow-lg shadow-emerald-600/20 active:scale-95 transition-all"
        >
          Publish Job
        </button>
      </div>
    </div>
  );
}

function Input({ label, placeholder, type = "text", value, onChange }: { label: string, placeholder: string, type?: string, value?: string, onChange?: any }) {
  return (
    <div className="space-y-1.5">
      <label className="text-xs font-bold text-gray-400 uppercase tracking-wider ml-1">{label}</label>
      <input 
        type={type}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        className="w-full bg-gray-50 border border-black/5 rounded-2xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all"
      />
    </div>
  );
}

function MessagesView({ messages, t, isRTL }: { messages: any[], t: (k: string) => string, isRTL: boolean }) {
  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-black px-2">{t('messages')}</h2>
      <div className="space-y-2">
        {messages.length > 0 ? messages.map(msg => (
          <ChatItem key={msg.id} name={msg.sender_name} message={msg.content} time={new Date(msg.sent_at).toLocaleTimeString()} unread={false} />
        )) : (
          <div className="text-center py-12 space-y-4">
            <div className="w-16 h-16 bg-gray-100 rounded-full mx-auto flex items-center justify-center text-gray-400">
              <MessageSquare size={32} />
            </div>
            <p className="text-gray-400 font-medium">No messages yet</p>
          </div>
        )}
      </div>
    </div>
  );
}

function ChatItem({ name, message, time, unread }: { name: string, message: string, time: string, unread: boolean, key?: any }) {
  return (
    <div className="bg-white p-4 rounded-2xl shadow-sm border border-black/5 flex gap-4 items-center hover:bg-gray-50 transition-colors cursor-pointer">
      <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-600 font-bold">
        {name[0]}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex justify-between items-center mb-1">
          <h4 className="font-bold truncate">{name}</h4>
          <span className="text-[10px] text-gray-400">{time}</span>
        </div>
        <p className={`text-sm truncate ${unread ? 'text-gray-900 font-bold' : 'text-gray-500'}`}>{message}</p>
      </div>
      {unread && <div className="w-2 h-2 bg-emerald-600 rounded-full" />}
    </div>
  );
}

function ProfileView({ user, t, isRTL, setLang, lang, setIsAdminMode, isAdmin, logout }: { user: UserType, t: (k: string) => string, isRTL: boolean, setLang: (l: Language) => void, lang: Language, setIsAdminMode: (b: boolean) => void, isAdmin: boolean, logout: () => void }) {
  return (
    <div className="space-y-6">
      {/* Profile Header */}
      <div className="bg-white p-6 rounded-3xl shadow-sm border border-black/5 text-center space-y-4">
        <div className="relative inline-block">
          <div className="w-24 h-24 bg-emerald-100 rounded-full mx-auto flex items-center justify-center text-emerald-600 text-3xl font-black shadow-inner">
            {user.name[0]}
          </div>
          <button className="absolute bottom-0 right-0 p-2 bg-white border border-black/5 rounded-full shadow-sm text-gray-400 hover:text-emerald-600">
            <Settings size={16} />
          </button>
        </div>
        <div>
          <h2 className="text-2xl font-black">{user.name}</h2>
          <p className="text-emerald-600 font-bold">{user.title || user.role}</p>
          <p className="text-gray-400 text-sm flex items-center justify-center gap-1 mt-1">
            <MapPin size={14} /> {user.location || 'Unknown'}
          </p>
        </div>
        <div className="flex gap-2">
          <button className="flex-1 py-3 border border-black/5 rounded-2xl font-bold text-sm hover:bg-gray-50 transition-all">
            {t('editProfile')}
          </button>
          {isAdmin && (
            <button 
              onClick={() => setIsAdminMode(true)}
              className="flex-1 py-3 bg-emerald-50 text-emerald-600 border border-emerald-100 rounded-2xl font-bold text-sm hover:bg-emerald-100 transition-all flex items-center justify-center gap-2"
            >
              <LayoutDashboard size={16} /> {t('adminDashboard')}
            </button>
          )}
        </div>
      </div>

      {/* Language Switcher */}
      <div className="bg-white p-6 rounded-3xl shadow-sm border border-black/5 space-y-4">
        <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-2">
          <Globe size={14} /> {t('language')}
        </h3>
        <div className="flex gap-2">
          <LangBtn active={lang === 'en'} label="English" onClick={() => setLang('en')} />
          <LangBtn active={lang === 'ku'} label="Kurdish" onClick={() => setLang('ku')} />
          <LangBtn active={lang === 'ar'} label="Arabic" onClick={() => setLang('ar')} />
        </div>
      </div>

      {/* Sections */}
      <ProfileSection title={t('bio')} content={user.bio || "No bio provided."} />
      <ProfileSection title={t('skills')} content={user.skills || "No skills listed."} />
      <ProfileSection title={t('experience')} content={user.experience || "No experience listed."} />
      <ProfileSection title={t('education')} content={user.education || "No education listed."} />

      <button 
        onClick={logout}
        className="w-full py-4 text-red-500 font-black flex items-center justify-center gap-2 hover:bg-red-50 rounded-2xl transition-all"
      >
        <LogOut size={20} /> {t('logout')}
      </button>
    </div>
  );
}

function LangBtn({ active, label, onClick }: { active: boolean, label: string, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${active ? 'bg-emerald-600 text-white shadow-md' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'}`}
    >
      {label}
    </button>
  );
}

function ProfileSection({ title, content }: { title: string, content: string }) {
  return (
    <div className="bg-white p-6 rounded-3xl shadow-sm border border-black/5 space-y-3">
      <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider">{title}</h3>
      <p className="text-gray-700 leading-relaxed">{content}</p>
    </div>
  );
}
