export interface Job {
  id: number;
  company_id: number;
  title: string;
  location: string;
  type: string;
  salary: string;
  description: string;
  requirements: string;
  posted_at: string;
  company_name: string;
  company_logo?: string;
  company_description?: string;
  translations?: string; // JSON string containing translations
}

export interface User {
  id: number;
  email: string;
  name: string;
  role: 'candidate' | 'employer' | 'admin';
  title?: string;
  location?: string;
  bio?: string;
  skills?: string;
  experience?: string;
  education?: string;
  avatar_url?: string;
}

export interface Application {
  id: number;
  user_id: number;
  job_id: number;
  status: 'sent' | 'viewed' | 'interview' | 'rejected' | 'offer';
  message: string;
  applied_at: string;
  job_title: string;
  company_name: string;
}
