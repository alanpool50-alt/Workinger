export type Language = 'en' | 'ku' | 'ar';

export interface Translation {
  [key: string]: {
    en: string;
    ku: string;
    ar: string;
  };
}

export const translations: Translation = {
  welcome: {
    en: "Welcome to Workinger",
    ku: "بەخێربێیت بۆ Workinger",
    ar: "مرحباً بك في Workinger"
  },
  findJobs: {
    en: "Find jobs and hire talent",
    ku: "کار بدۆزەوە یان کارمەند دابنێ",
    ar: "اعثر على وظائف أو قم بالتوظيف"
  },
  getStarted: {
    en: "Get Started",
    ku: "دەستپێبکە",
    ar: "ابدأ"
  },
  explore: {
    en: "Explore Jobs",
    ku: "گەڕان بە کارەکان",
    ar: "استكشاف الوظائف"
  },
  saved: {
    en: "Saved",
    ku: "پاشەکەوتکراو",
    ar: "المحفوظات"
  },
  postJob: {
    en: "Post Job",
    ku: "دانانی کار",
    ar: "نشر وظيفة"
  },
  messages: {
    en: "Messages",
    ku: "پەیامەکان",
    ar: "الرسائل"
  },
  profile: {
    en: "Profile",
    ku: "پرۆفایل",
    ar: "الملف الشخصي"
  },
  searchJobs: {
    en: "Search jobs",
    ku: "گەڕان بە کار",
    ar: "البحث عن وظائف"
  },
  location: {
    en: "Location",
    ku: "شوێن",
    ar: "الموقع"
  },
  filters: {
    en: "Filters",
    ku: "فلتەرەکان",
    ar: "الفلاتر"
  },
  remote: {
    en: "Remote",
    ku: "دوورکار",
    ar: "عن بعد"
  },
  fullTime: {
    en: "Full Time",
    ku: "تەواو کات",
    ar: "دوام كامل"
  },
  partTime: {
    en: "Part Time",
    ku: "نیوە کات",
    ar: "دوام جزئي"
  },
  saveJob: {
    en: "Save Job",
    ku: "پاشەکەوتکردنی کار",
    ar: "حفظ الوظيفة"
  },
  openJob: {
    en: "Open Job",
    ku: "بینینی کار",
    ar: "عرض الوظيفة"
  },
  apply: {
    en: "Apply",
    ku: "داواکاری کار",
    ar: "التقديم"
  },
  jobDescription: {
    en: "Job Description",
    ku: "وەسفی کار",
    ar: "وصف الوظيفة"
  },
  requirements: {
    en: "Requirements",
    ku: "داواکاریەکان",
    ar: "المتطلبات"
  },
  selectResume: {
    en: "Select Resume",
    ku: "هەڵبژاردنی CV",
    ar: "اختيار السيرة الذاتية"
  },
  writeMessage: {
    en: "Write Message",
    ku: "نووسینی پەیام",
    ar: "كتابة رسالة"
  },
  sendApplication: {
    en: "Send Application",
    ku: "ناردنی داواکاری",
    ar: "إرسال الطلب"
  },
  applicationSent: {
    en: "Application Sent",
    ku: "داواکاری نێردرا",
    ar: "تم إرسال الطلب"
  },
  backToJobs: {
    en: "Back to Jobs",
    ku: "گەڕانەوە بۆ کارەکان",
    ar: "العودة للوظائف"
  },
  savedJobs: {
    en: "Saved Jobs",
    ku: "کارە پاشەکەوتکراوەکان",
    ar: "الوظائف المحفوظة"
  },
  appliedJobs: {
    en: "Applied Jobs",
    ku: "کارە داواکراوەکان",
    ar: "الوظائف المتقدم لها"
  },
  recentlyViewed: {
    en: "Recently Viewed",
    ku: "تازە بینراو",
    ar: "شوهدت مؤخراً"
  },
  editProfile: {
    en: "Edit Profile",
    ku: "دەستکاریکردنی پرۆفایل",
    ar: "تعديل الملف"
  },
  bio: {
    en: "Bio",
    ku: "بایۆ",
    ar: "نبذة"
  },
  skills: {
    en: "Skills",
    ku: "توانا",
    ar: "المهارات"
  },
  experience: {
    en: "Experience",
    ku: "ئەزموون",
    ar: "الخبرة"
  },
  education: {
    en: "Education",
    ku: "خوێندن",
    ar: "التعليم"
  },
  account: {
    en: "Account",
    ku: "هەژمار",
    ar: "الحساب"
  },
  notifications: {
    en: "Notifications",
    ku: "ئاگادارکردنەوەکان",
    ar: "الإشعارات"
  },
  privacy: {
    en: "Privacy",
    ku: "تایبەتمەندی",
    ar: "الخصوصية"
  },
  language: {
    en: "Language",
    ku: "زمان",
    ar: "اللغة"
  },
  logout: {
    en: "Logout",
    ku: "چوونەدەرەوە",
    ar: "تسجيل الخروج"
  },
  adminDashboard: {
    en: "Admin Dashboard",
    ku: "داشبۆردی ئەدمین",
    ar: "لوحة تحكم المسؤول"
  },
  analytics: {
    en: "Analytics",
    ku: "ئامارەکان",
    ar: "التحليلات"
  },
  database: {
    en: "Database",
    ku: "داتابەیس",
    ar: "قاعدة البيانات"
  },
  totalUsers: {
    en: "Total Users",
    ku: "کۆی بەکارهێنەران",
    ar: "إجمالي المستخدمين"
  },
  totalJobs: {
    en: "Total Jobs",
    ku: "کۆی کارەکان",
    ar: "إجمالي الوظائف"
  },
  totalApplications: {
    en: "Total Applications",
    ku: "کۆی داواکاریەکان",
    ar: "إجمالي الطلبات"
  },
  login: {
    en: "Login",
    ku: "چوونەژوورەوە",
    ar: "تسجيل الدخول"
  },
  seoTitle: {
    en: "Workinger | Find Your Dream Job & Hire Top Talent",
    ku: "Workinger | کارەکەی خەونت بدۆزەرەوە و باشترین بەهرەمەند دابنێ",
    ar: "Workinger | اعثر على وظيفة أحلامك ووظف أفضل المواهب"
  },
  seoDescription: {
    en: "Search millions of jobs online to find the next step in your career. With tools for job search, resumes, company reviews and more, Workinger is with you every step of the way. Find jobs in English, Kurdish, and Arabic.",
    ku: "گەڕان بەدوای ملیۆنان کاردا بکە لە ئۆنلاین بۆ دۆزینەوەی هەنگاوی داهاتووی کارەکەت. بە ئامرازەکانی گەڕان بەدوای کار، سیڤی، و زیاتر، Workinger لە هەموو هەنگاوێکدا لەگەڵتە. کار بدۆزەرەوە بە زمانەکانی ئینگلیزی، کوردی و عەرەبی.",
    ar: "ابحث عن ملايين الوظائف عبر الإنترنت لتجد الخطوة التالية في مسيرتك المهنية. مع أدوات البحث عن وظائف، والسير الذاتية، وتقييمات الشركات والمزيد، Workinger معك في كل خطوة. ابحث عن وظائف باللغات الإنجليزية والكردية والعربية."
  },
  jobAt: {
    en: "at",
    ku: "لە",
    ar: "في"
  }
};
